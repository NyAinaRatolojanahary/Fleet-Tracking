package com.application.fleettracking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FleetTrackingApplication {

	public static void main(String[] args) {
		SpringApplication.run(FleetTrackingApplication.class, args);
	}

}
